#!/usr/bin/env bash
set -euo pipefail

PATCH_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

copy_file() {
  local rel="$1"
  mkdir -p "$(dirname "$rel")"
  cp "$PATCH_DIR/$rel" "$rel"
  echo "updated $rel"
}

copy_file "tools/maya/run_apply_eye_performance_events.py"

PATCH_DIR="$PATCH_DIR" python3 - <<'PY'
from pathlib import Path
import os
import re

patch_dir = Path(os.environ["PATCH_DIR"])
p = Path("src/expregaze_jali/maya_apply_eye_performance.py")
text = p.read_text(encoding="utf-8")

new_load = patch_dir.joinpath("patch_fragments/load_maya_eye_config.pyfrag").read_text(encoding="utf-8").strip()
new_apply = patch_dir.joinpath("patch_fragments/apply_eye_performance_events_from_config.pyfrag").read_text(encoding="utf-8").strip()

# Replace load_maya_eye_config block, and include the helper functions before it.
load_pattern = re.compile(
    r"\ndef load_maya_eye_config\(\s*path: str \| Path\s*\) -> dict\[str, Any\]:\n"
    r".*?\n(?=def resolve_repo_path\()",
    re.DOTALL,
)
if not load_pattern.search(text):
    # If a prior patch already added helpers/signature, replace from _mapping/load block to resolve_repo_path.
    alt_start = text.find("\ndef _mapping(")
    alt_end = text.find("\ndef resolve_repo_path(", alt_start)
    if alt_start >= 0 and alt_end >= 0:
        text = text[:alt_start] + "\n" + new_load + "\n\n" + text[alt_end + 1:]
    else:
        raise RuntimeError("Could not replace load_maya_eye_config block.")
else:
    text = load_pattern.sub("\n" + new_load + "\n\n", text)

apply_pattern = re.compile(
    r"\ndef apply_eye_performance_events_from_config\(\s*config_path: str \| Path\s*\) -> None:\n"
    r".*\Z",
    re.DOTALL,
)
if not apply_pattern.search(text):
    alt_start = text.find("\ndef apply_eye_performance_events_from_config(")
    if alt_start < 0:
        raise RuntimeError("Could not find apply_eye_performance_events_from_config block.")
    text = text[:alt_start] + "\n" + new_apply + "\n"
else:
    text = apply_pattern.sub("\n" + new_apply + "\n", text)

p.write_text(text, encoding="utf-8")
print("updated src/expregaze_jali/maya_apply_eye_performance.py")
PY

python3 -m py_compile src/expregaze_jali/maya_apply_eye_performance.py

echo
echo "Done. Re-run in Maya:"
echo '  exec(open(r"\\wsl.localhost\Ubuntu-24.04\home\sia\JaliTest\tools\maya\run_apply_eye_performance_events.py", encoding="utf-8").read())'
