# JALITEST eye sequence config patch

Fixes:

```text
KeyError: 'eye_events_path'
```

Cause: `maya_apply_eye_performance.py` was still using only `configs/maya/valleygirl.yaml`.
After the config cleanup, `clip_name`, `fps`, and `clip_end_frame` live in
`configs/sequences/s038_1talk.yaml`, so the eye event path was not inferred.

This patch:
- updates `tools/maya/run_apply_eye_performance_events.py`
- reloads the Maya module before running
- passes `sequence_config_path` and `project_config_path`
- infers:
  `data/processed/gaze_script/{clip_name}__eye_performance_events_resolved.json`
