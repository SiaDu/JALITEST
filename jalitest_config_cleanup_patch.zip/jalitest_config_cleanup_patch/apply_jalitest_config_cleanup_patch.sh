#!/usr/bin/env bash
set -euo pipefail

PATCH_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(pwd)"

echo "Applying JALITEST config cleanup patch to: $REPO_ROOT"

# Remove legacy / duplicated configs and old script location.
rm -f configs/base.yaml
rm -f configs/path_local.yaml
rm -f configs/path_local.example.yaml
rm -f configs/tt0032138.yaml
rm -rf configs/runs
rm -f configs/maya/jali_proto_candidate_001_eye.yaml
rm -f configs/maya/jali_proto_candidate_001_gaze.yaml
rm -f configs/maya/jali_proto_candidate_001_jali_annotation.yaml
rm -rf src/maya

# Copy replacement files.
for path in \
  README.md \
  configs/llm.yaml \
  configs/project.yaml \
  configs/jali_emotion_options.yaml \
  configs/performance_rules.yaml \
  configs/sequences/Jali_proto_candidate_001_ProfessorCrystal.yaml \
  configs/sequences/example.yaml \
  configs/maya/valleygirl.yaml \
  scripts/02_parse_textgrid.sh \
  src/expregaze_jali/actor_context_builder.py \
  src/expregaze_jali/actor_prompt_builder.py \
  src/expregaze_jali/build_actor_prompt.py \
  src/expregaze_jali/config_utils.py \
  src/expregaze_jali/maya_apply_eye_performance.py \
  src/expregaze_jali/maya_apply_gaze.py \
  src/expregaze_jali/maya_apply_jali_annotation.py \
  src/expregaze_jali/process_performance_annotation.py \
  src/expregaze_jali/run_actor_llm.py \
  src/expregaze_jali/textgrid_parser.py \
  tools/maya/print_jali_controls.py \
  tools/maya/run_apply_eye_performance_events.py \
  tools/maya/run_apply_gaze_events.py \
  tools/maya/run_apply_jali_annotation.py \
  tests/test_actor_prompt_builder.py \
  tests/test_expregaze_jali_pipeline.py \
  tests/test_maya_apply_gaze_config.py
 do
  mkdir -p "$(dirname "$path")"
  cp "$PATCH_DIR/$path" "$REPO_ROOT/$path"
 done

chmod +x scripts/02_parse_textgrid.sh

echo "Done."
echo "Run: PYTHONPATH=src python3 -m pytest -q"
