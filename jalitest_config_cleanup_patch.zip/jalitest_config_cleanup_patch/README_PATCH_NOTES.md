# JALITEST config cleanup patch

This patch restructures `configs/` and removes duplicated path YAMLs.

## New config layout

```text
configs/
  llm.yaml
  project.yaml
  jali_emotion_options.yaml
  performance_rules.yaml
  sequences/
    Jali_proto_candidate_001_ProfessorCrystal.yaml
    example.yaml
  maya/
    valleygirl.yaml
```

## Removed legacy files

```text
configs/base.yaml
configs/path_local.yaml
configs/path_local.example.yaml
configs/tt0032138.yaml
configs/runs/
configs/maya/jali_proto_candidate_001_eye.yaml
configs/maya/jali_proto_candidate_001_gaze.yaml
configs/maya/jali_proto_candidate_001_jali_annotation.yaml
src/maya/
```

## Behavior changes

- `configs/base.yaml` is replaced by `configs/llm.yaml`.
- Step 00 uses `configs/project.yaml` + one sequence YAML.
- Step 00 still injects only `configs/jali_emotion_options.yaml` and `configs/performance_rules.yaml` as prompt extra config.
- Step 02 derives TextGrid output paths from sequence id / clip name.
- Maya runner scripts moved from `src/maya/` to `tools/maya/`.
- The three Maya adapter configs are merged into `configs/maya/valleygirl.yaml`.

## Apply

```bash
cd ~/JaliTest
unzip -o /path/to/jalitest_config_cleanup_patch.zip -d /tmp/jalitest_patch
bash /tmp/jalitest_patch/jalitest_config_cleanup_patch/apply_jalitest_config_cleanup_patch.sh
```

## Run

```bash
bash scripts/00_build_actor_prompt.sh --overwrite
bash scripts/01_run_actor_llm.sh --llm-config configs/llm.yaml --overwrite
bash scripts/02_parse_textgrid.sh --sequence-config configs/sequences/Jali_proto_candidate_001_ProfessorCrystal.yaml
bash scripts/03_compile_actor_annotation.sh --sequence-id Jali_proto_candidate_001_ProfessorCrystal --overwrite
bash scripts/04_validate_actor_outputs.sh --sequence-id Jali_proto_candidate_001_ProfessorCrystal
```

## Verified

```text
PYTHONPATH=src python3 -m compileall -q src tests
PYTHONPATH=src python3 -m pytest -q
# 17 passed
```
