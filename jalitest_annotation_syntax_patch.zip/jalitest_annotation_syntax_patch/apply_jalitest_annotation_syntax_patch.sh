#!/usr/bin/env bash
set -euo pipefail

PATCH_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(pwd)"

copy_file() {
  local rel="$1"
  mkdir -p "${REPO_DIR}/$(dirname "$rel")"
  cp "${PATCH_DIR}/${rel}" "${REPO_DIR}/${rel}"
  echo "updated ${rel}"
}

copy_file "prompts/actor_performance_annotation_prompt_v2.md"
copy_file "configs/performance_rules.yaml"
copy_file "src/expregaze_jali/performance_annotation_parser.py"
copy_file "src/expregaze_jali/target_resolution.py"
copy_file "src/expregaze_jali/compile_performance_annotation.py"
copy_file "tests/test_target_resolution_and_parser.py"

echo
echo "Done. Recommended checks:"
echo "  PYTHONPATH=src python3 -m compileall -q src tests"
echo "  PYTHONPATH=src python3 -m pytest -q"
echo "  bash scripts/03_compile_actor_annotation.sh --overwrite"
