# JALITEST annotation syntax patch

Fixes the LLM output issue where the `[ANNOTATION]` section used bare tokens like:

```text
l01=-2 That's right. g01=GAZE-CHARACTER_DOROTHY Here -- sit right down here.
```

That is not the canonical actor annotation syntax. The canonical syntax is XML-like angle tags:

```text
<l01=-2>That's right.</l01> <g01=GAZE-CHARACTER_DOROTHY>Here -- sit right down here.</g01>
```

## Changes

- Strengthens `prompts/actor_performance_annotation_prompt_v2.md` with explicit correct/incorrect examples.
- Strengthens `configs/performance_rules.yaml` with canonical tag syntax rules.
- Adds parser recovery for bare tags inside `[ANNOTATION]` so current bad LLM output can still compile.
- Prevents bare tag tokens from entering `clean_transcript`, which was causing TextGrid alignment warnings.
- Adds support for typed gaze targets such as `CHARACTER_DOROTHY` and `OBJECT_CRYSTAL`.
- Writes `normalized_bare_tags` into diagnostics and prints a warning when recovery was used.
- Adds tests for bare-tag recovery and typed target resolution.

## Apply

```bash
cd ~/JaliTest
unzip -o /path/to/jalitest_annotation_syntax_patch.zip -d /tmp/jalitest_patch
bash /tmp/jalitest_patch/jalitest_annotation_syntax_patch/apply_jalitest_annotation_syntax_patch.sh
```

## Re-run current bad annotation without another LLM call

```bash
bash scripts/03_compile_actor_annotation.sh --overwrite
```

Then inspect:

```bash
python3 - <<'PY'
import json
p='data/processed/gaze_script/Jali_proto_candidate_001_ProfessorCrystal__gaze_events_resolved.json'
d=json.load(open(p, encoding='utf-8'))
print('alignment_warnings:', len(d.get('diagnostics', {}).get('alignment_warnings', [])))
print('normalized_bare_tags:', len(d.get('diagnostics', {}).get('normalized_bare_tags', [])))
print('events:', len(d.get('events', [])))
PY
```

`normalized_bare_tags` may be non-zero for the already-generated annotation. Future Step 01 output should use angle tags if the updated prompt is used.
