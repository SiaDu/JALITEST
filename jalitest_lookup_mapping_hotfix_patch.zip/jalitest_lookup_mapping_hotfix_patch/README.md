# JALITEST lookup mapping hotfix

Fixes:

```text
TypeError: _lookup_mapping() takes 2 positional arguments but 3 were given
```

The dynamic target code needs `_lookup_mapping(mapping, key, node_name)` for fallback
lookups, so `_lookup_mapping` now accepts one or more candidate keys.

Apply:

```bash
cd ~/JaliTest
unzip -o /path/to/jalitest_lookup_mapping_hotfix_patch.zip -d /tmp/jalitest_patch
bash /tmp/jalitest_patch/jalitest_lookup_mapping_hotfix_patch/apply_jalitest_lookup_mapping_hotfix_patch.sh
```
