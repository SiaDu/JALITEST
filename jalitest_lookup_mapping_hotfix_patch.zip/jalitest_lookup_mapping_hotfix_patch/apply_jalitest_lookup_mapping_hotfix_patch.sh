#!/usr/bin/env bash
set -euo pipefail

python3 - <<'PY'
from pathlib import Path

p = Path("src/expregaze_jali/maya_apply_gaze.py")
text = p.read_text(encoding="utf-8")

old = 'def _lookup_mapping(mapping: dict[str, Any], key: str) -> Any:\n    if key in mapping:\n        return mapping[key]\n    upper_key = key.upper()\n    for candidate, value in mapping.items():\n        if str(candidate).upper() == upper_key:\n            return value\n    return None\n'

new = 'def _lookup_mapping(mapping: dict[str, Any], *keys: str) -> Any:\n    """Case-insensitive mapping lookup for one or more candidate keys."""\n    if not isinstance(mapping, dict):\n        return None\n\n    for key in keys:\n        if key in mapping:\n            return mapping[key]\n\n    upper_keys = {str(key).upper() for key in keys if str(key)}\n    for candidate, value in mapping.items():\n        if str(candidate).upper() in upper_keys:\n            return value\n\n    return None\n'

if old not in text:
    start = text.find("def _lookup_mapping(")
    end = text.find("\n\ndef resolve_target_alias(", start)
    if start < 0 or end < 0:
        raise SystemExit("Could not find _lookup_mapping block in maya_apply_gaze.py")
    text = text[:start] + new + text[end:]
else:
    text = text.replace(old, new)

p.write_text(text, encoding="utf-8")
print("updated src/expregaze_jali/maya_apply_gaze.py: _lookup_mapping now accepts multiple keys")
PY

python3 -m py_compile src/expregaze_jali/maya_apply_gaze.py

echo
echo "Done. Re-run in Maya:"
echo '  exec(open(r"\\wsl.localhost\Ubuntu-24.04\home\sia\JaliTest\tools\maya\run_create_gaze_targets.py", encoding="utf-8").read())'
