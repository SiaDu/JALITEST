# JALITEST Maya dynamic targets patch v2

Fixes the bad v1 patch script quoting issue.

This patch:
- reads gaze targets dynamically from `{sequence_id}__gaze_events_resolved.json`
- creates locators with `run_create_gaze_targets.py`
- keeps `run_apply_gaze_events.py` apply-only

Apply from repo root:

```bash
cd ~/JaliTest
unzip -o /path/to/jalitest_maya_dynamic_targets_patch_v2.zip -d /tmp/jalitest_patch
bash /tmp/jalitest_patch/jalitest_maya_dynamic_targets_patch_v2/apply_jalitest_maya_dynamic_targets_patch_v2.sh
```
