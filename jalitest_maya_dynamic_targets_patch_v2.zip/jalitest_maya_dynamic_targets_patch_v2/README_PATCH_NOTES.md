# Patch notes

v2 fixes the SyntaxError in the previous apply script by storing code fragments
as separate files instead of embedding nested triple-quoted Python strings.
