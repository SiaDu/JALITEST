#!/usr/bin/env bash
set -euo pipefail

PATCH_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(pwd)"

copy_file() {
  local rel="$1"
  mkdir -p "$PROJECT_ROOT/$(dirname "$rel")"
  cp "$PATCH_DIR/$rel" "$PROJECT_ROOT/$rel"
  echo "updated $rel"
}

copy_file "tools/maya/run_create_gaze_targets.py"
copy_file "tools/maya/run_apply_gaze_events.py"
copy_file "configs/maya/valleygirl.yaml"

PATCH_DIR="$PATCH_DIR" python3 - <<'PY'
from pathlib import Path
import os
import re

patch_dir = Path(os.environ["PATCH_DIR"])
p = Path("src/expregaze_jali/maya_apply_gaze.py")
text = p.read_text(encoding="utf-8")

dynamic_code = patch_dir.joinpath("patch_fragments/dynamic_helpers.pyfrag").read_text(encoding="utf-8")
new_apply = patch_dir.joinpath("patch_fragments/apply_gaze_events_from_config.pyfrag").read_text(encoding="utf-8")

# Remove a previous dynamic helper block if present, then insert fresh copy.
start_marker = "\n_DIRECTION_TARGETS = {\n"
end_marker = "\n\ndef apply_gaze_events_from_config(\n"
if start_marker in text and end_marker in text:
    before, rest = text.split(start_marker, 1)
    _old_helper, after = rest.split(end_marker, 1)
    text = before + end_marker + after

if "def build_dynamic_gaze_target_map(" not in text:
    marker = "\n\ndef apply_gaze_events_from_config(\n"
    if marker not in text:
        raise RuntimeError("Could not find apply_gaze_events_from_config insertion point.")
    text = text.replace(marker, "\n" + dynamic_code.rstrip() + marker)

pattern = re.compile(
    r"\ndef apply_gaze_events_from_config\(\n"
    r"    config_path: str \| Path,\n"
    r"    \*,\n"
    r"    sequence_config_path: str \| Path \| None = None,\n"
    r"    project_config_path: str \| Path \| None = None,\n"
    r"\) -> None:\n.*\Z",
    re.DOTALL,
)

if not pattern.search(text):
    raise RuntimeError("Could not replace apply_gaze_events_from_config body.")

text = pattern.sub("\n" + new_apply.strip() + "\n", text)
p.write_text(text, encoding="utf-8")
print("updated src/expregaze_jali/maya_apply_gaze.py")
PY

python3 -m py_compile src/expregaze_jali/maya_apply_gaze.py

echo
echo "Done."
echo
echo "Maya create target locators:"
echo '  exec(open(r"\\wsl.localhost\Ubuntu-24.04\home\sia\JaliTest\tools\maya\run_create_gaze_targets.py", encoding="utf-8").read())'
echo
echo "Then manually move locators in Maya, then apply gaze:"
echo '  exec(open(r"\\wsl.localhost\Ubuntu-24.04\home\sia\JaliTest\tools\maya\run_apply_gaze_events.py", encoding="utf-8").read())'
