# Patch notes

v3:
- removes all newline-containing f-string literals in the generated fragment
- replaces the tail of `maya_apply_gaze.py` from the first dynamic/apply marker
  to EOF, so broken v1/v2 partial insertions are removed
- runs `python3 -m py_compile src/expregaze_jali/maya_apply_gaze.py`
