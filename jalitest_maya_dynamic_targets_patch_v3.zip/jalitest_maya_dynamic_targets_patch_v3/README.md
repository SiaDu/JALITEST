# JALITEST Maya dynamic targets patch v3

This fixes the v2 unterminated f-string issue and hard-cleans the broken
`maya_apply_gaze.py` tail from previous patch attempts.

Apply:

```bash
cd ~/JaliTest
unzip -o /path/to/jalitest_maya_dynamic_targets_patch_v3.zip -d /tmp/jalitest_patch
bash /tmp/jalitest_patch/jalitest_maya_dynamic_targets_patch_v3/apply_jalitest_maya_dynamic_targets_patch_v3.sh
```
