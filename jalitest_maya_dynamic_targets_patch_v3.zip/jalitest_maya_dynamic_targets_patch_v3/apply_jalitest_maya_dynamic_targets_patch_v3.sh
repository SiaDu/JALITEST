#!/usr/bin/env bash
set -euo pipefail

PATCH_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(pwd)"

copy_file() {
  local rel="$1"
  mkdir -p "$PROJECT_ROOT/$(dirname "$rel")"
  cp "$PATCH_DIR/$rel" "$PROJECT_ROOT/$rel"
  echo "updated $rel"
}

copy_file "tools/maya/run_create_gaze_targets.py"
copy_file "tools/maya/run_apply_gaze_events.py"
copy_file "configs/maya/valleygirl.yaml"

PATCH_DIR="$PATCH_DIR" python3 - <<'PY'
from pathlib import Path
import os

patch_dir = Path(os.environ["PATCH_DIR"])
p = Path("src/expregaze_jali/maya_apply_gaze.py")
text = p.read_text(encoding="utf-8")

dynamic_code = patch_dir.joinpath("patch_fragments/dynamic_helpers.pyfrag").read_text(encoding="utf-8").strip()
new_apply = patch_dir.joinpath("patch_fragments/apply_gaze_events_from_config.pyfrag").read_text(encoding="utf-8").strip()

# Hard-clean the broken tail from any earlier v1/v2 attempt.
marker_positions = []
for marker in (
    "\n_DIRECTION_TARGETS = {",
    "\ndef build_dynamic_gaze_target_map(",
    "\ndef ensure_dynamic_gaze_target_locators(",
    "\ndef apply_gaze_events_from_config(",
):
    idx = text.find(marker)
    if idx >= 0:
        marker_positions.append(idx)

if not marker_positions:
    raise RuntimeError("Could not find a safe replacement point in maya_apply_gaze.py")

cut = min(marker_positions)
text = text[:cut].rstrip() + "\n\n" + dynamic_code + "\n\n" + new_apply + "\n"
p.write_text(text, encoding="utf-8")
print("updated src/expregaze_jali/maya_apply_gaze.py")
PY

python3 -m py_compile src/expregaze_jali/maya_apply_gaze.py

echo
echo "Done."
echo
echo "Maya create target locators:"
echo '  exec(open(r"\\wsl.localhost\Ubuntu-24.04\home\sia\JaliTest\tools\maya\run_create_gaze_targets.py", encoding="utf-8").read())'
echo
echo "Then manually move locators in Maya, then apply gaze:"
echo '  exec(open(r"\\wsl.localhost\Ubuntu-24.04\home\sia\JaliTest\tools\maya\run_apply_gaze_events.py", encoding="utf-8").read())'
