#!/usr/bin/env bash
set -euo pipefail

PATCH_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(pwd)"

copy_file() {
  local rel="$1"
  mkdir -p "$REPO_ROOT/$(dirname "$rel")"
  cp "$PATCH_DIR/$rel" "$REPO_ROOT/$rel"
  echo "updated $rel"
}

copy_file "src/expregaze_jali/maya_apply_gaze.py"
copy_file "tools/maya/run_apply_gaze_events.py"
copy_file "configs/maya/valleygirl.yaml"
copy_file "prompts/actor_performance_annotation_prompt_v2.md"
copy_file "configs/performance_rules.yaml"
copy_file "src/expregaze_jali/performance_annotation_parser.py"
copy_file "tests/test_target_resolution_and_parser.py"

echo "Patch applied. Suggested checks:"
echo "  PYTHONPATH=src python3 -m compileall -q src tests"
echo "  PYTHONPATH=src python3 -m pytest -q"
