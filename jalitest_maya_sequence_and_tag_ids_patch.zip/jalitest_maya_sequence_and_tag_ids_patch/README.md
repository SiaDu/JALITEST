# Patch contents

- `src/expregaze_jali/maya_apply_gaze.py`
- `tools/maya/run_apply_gaze_events.py`
- `configs/maya/valleygirl.yaml`
- `prompts/actor_performance_annotation_prompt_v2.md`
- `configs/performance_rules.yaml`
- `src/expregaze_jali/performance_annotation_parser.py`
- `tests/test_target_resolution_and_parser.py`

Run `apply_jalitest_maya_sequence_and_tag_ids_patch.sh` from the unpacked patch directory.
