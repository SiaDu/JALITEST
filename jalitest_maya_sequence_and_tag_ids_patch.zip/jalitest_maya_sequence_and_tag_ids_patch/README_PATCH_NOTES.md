# JALITEST Maya sequence + tag ID cleanup patch

This patch fixes two issues:

1. `tools/maya/run_apply_gaze_events.py` now reads the active sequence config, so Maya gaze apply uses `configs/sequences/s038_1talk.yaml` instead of the stale `clip_name` inside `configs/maya/valleygirl.yaml`.
2. Annotation syntax is tightened so the LLM should stop reusing IDs such as `m01` repeatedly. The parser also renumbers duplicate IDs defensively when old/bad output still does it.

## Apply

```bash
cd ~/JaliTest
unzip -o /path/to/jalitest_maya_sequence_and_tag_ids_patch.zip -d /tmp/jalitest_patch
bash /tmp/jalitest_patch/jalitest_maya_sequence_and_tag_ids_patch/apply_jalitest_maya_sequence_and_tag_ids_patch.sh
```

## Run Maya gaze apply

Default sequence is `configs/sequences/s038_1talk.yaml`:

```python
exec(open(r"\\wsl.localhost\Ubuntu-24.04\home\sia\JaliTest\tools\maya\run_apply_gaze_events.py", encoding="utf-8").read())
```

To run another sequence in Maya:

```python
import os
os.environ["JALITEST_SEQUENCE_CONFIG"] = r"\\wsl.localhost\Ubuntu-24.04\home\sia\JaliTest\configs\sequences\YOUR_SEQUENCE.yaml"
exec(open(r"\\wsl.localhost\Ubuntu-24.04\home\sia\JaliTest\tools\maya\run_apply_gaze_events.py", encoding="utf-8").read())
```

## Important

Run Step 03 for the same sequence before Maya apply:

```bash
bash scripts/03_compile_actor_annotation.sh --sequence-id s038_1talk --overwrite
```

The expected gaze events file is:

```text
data/processed/gaze_script/s038_1talk__gaze_events_resolved.json
```
