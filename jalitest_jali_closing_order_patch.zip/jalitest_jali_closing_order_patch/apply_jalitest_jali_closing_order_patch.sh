#!/usr/bin/env bash
set -euo pipefail

PATCH_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(pwd)"

copy_file() {
  local rel="$1"
  mkdir -p "$PROJECT_ROOT/$(dirname "$rel")"
  cp "$PATCH_DIR/$rel" "$PROJECT_ROOT/$rel"
  echo "updated $rel"
}

copy_file "src/expregaze_jali/jali_annotation_exporter.py"
copy_file "tests/test_expregaze_jali_pipeline.py"

echo
echo "Done. Suggested checks:"
echo "  PYTHONPATH=src python3 -m compileall -q src tests"
echo "  PYTHONPATH=src python3 -m pytest -q"
echo
echo "Then regenerate JALI transcript output:"
echo "  bash scripts/03_compile_actor_annotation.sh --sequence-id s038_1talk --overwrite"
