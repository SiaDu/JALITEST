# JALITEST JALI closing-order patch

This patch fixes the JALI-facing transcript exporter.

JALI Text Editor tag order in this project should close mask/heart tags in the
same order they opened when they share the same span end.

Before:

```text
<mask=Smug-60><heart=Contempt-20>text</heart=Contempt-20></mask=Smug-60>
```

After:

```text
<mask=Smug-60><heart=Contempt-20>text</mask=Smug-60></heart=Contempt-20>
```

Apply from repo root:

```bash
bash apply_jalitest_jali_closing_order_patch.sh
```

Then regenerate:

```bash
bash scripts/03_compile_actor_annotation.sh --sequence-id s038_1talk --overwrite
```
