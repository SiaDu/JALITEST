# Patch notes

Changed:
- `src/expregaze_jali/jali_annotation_exporter.py`
  - close mask/heart tags by ascending event order at the same transcript position.
  - added docstring explaining this is intentionally JALI-order, not XML stack order.

- `tests/test_expregaze_jali_pipeline.py`
  - added regression test for `<mask><heart>text</mask></heart>` output.

Why:
- The old exporter closed by reverse order (`reverse=True`), producing XML-like nesting.
- The JALI-facing transcript in this project expects close order to mirror open order.
