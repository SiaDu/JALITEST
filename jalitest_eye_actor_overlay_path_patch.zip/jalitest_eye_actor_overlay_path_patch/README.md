# JALITEST eye actor-overlay path patch

Fixes the Maya eye-performance adapter to use the current Step 03 output:

```text
{clip}__actor_overlay_events.json
```

instead of the old/nonexistent:

```text
{clip}__eye_performance_events_resolved.json
```

It also normalizes the current flat actor-overlay shape:

```json
{"events": [{"type": "lid_state"}, {"type": "performative_blink"}]}
```

into the older grouped shape consumed by the Maya eyelid applier.
