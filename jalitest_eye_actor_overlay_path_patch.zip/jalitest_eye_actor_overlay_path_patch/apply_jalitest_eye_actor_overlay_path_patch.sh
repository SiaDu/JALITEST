#!/usr/bin/env bash
set -euo pipefail

PATCH_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

PATCH_DIR="$PATCH_DIR" python3 - <<'PY'
from pathlib import Path
import os
import re

patch_dir = Path(os.environ["PATCH_DIR"])
p = Path("src/expregaze_jali/maya_apply_eye_performance.py")
text = p.read_text(encoding="utf-8")

# 1) Current compile output is {clip}__actor_overlay_events.json, not
#    {clip}__eye_performance_events_resolved.json.
text = text.replace(
    "{clip_name}__eye_performance_events_resolved.json",
    "{clip_name}__actor_overlay_events.json",
)
text = text.replace(
    "{clip}__eye_performance_events_resolved.json",
    "{clip}__actor_overlay_events.json",
)
text = text.replace(
    "Eye performance events JSON not found:",
    "Actor overlay events JSON not found:",
)

# 2) Normalize actor_overlay_events.json into the old grouped shape expected by
#    apply_eye_performance_events().
new_load = patch_dir.joinpath("patch_fragments/load_eye_events.pyfrag").read_text(encoding="utf-8").strip()

pattern = re.compile(
    r"\ndef _load_eye_events\(path: str \| Path\) -> dict\[str, Any\]:\n"
    r".*?\n(?=\ndef _plug\()",
    re.DOTALL,
)
if not pattern.search(text):
    raise RuntimeError("Could not find _load_eye_events block.")
text = pattern.sub("\n" + new_load + "\n", text)

p.write_text(text, encoding="utf-8")
print("updated src/expregaze_jali/maya_apply_eye_performance.py")
PY

python3 -m py_compile src/expregaze_jali/maya_apply_eye_performance.py

echo
echo "Done. Re-run in Maya:"
echo '  exec(open(r"\\wsl.localhost\Ubuntu-24.04\home\sia\JaliTest\tools\maya\run_apply_eye_performance_events.py", encoding="utf-8").read())'
