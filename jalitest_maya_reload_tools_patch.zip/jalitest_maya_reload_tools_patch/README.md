# JALITEST Maya reload tools patch

Maya caches imported Python modules across Script Editor runs. This patch updates:

- `tools/maya/run_create_gaze_targets.py`
- `tools/maya/run_apply_gaze_events.py`

to `importlib.reload(expregaze_jali.maya_apply_gaze)` before calling functions.

Apply:

```bash
cd ~/JaliTest
unzip -o /path/to/jalitest_maya_reload_tools_patch.zip -d /tmp/jalitest_patch
bash /tmp/jalitest_patch/jalitest_maya_reload_tools_patch/apply_jalitest_maya_reload_tools_patch.sh
```
