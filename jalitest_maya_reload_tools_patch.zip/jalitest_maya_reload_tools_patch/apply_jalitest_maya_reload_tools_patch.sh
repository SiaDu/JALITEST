#!/usr/bin/env bash
set -euo pipefail

PATCH_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(pwd)"

copy_file() {
  local rel="$1"
  mkdir -p "$PROJECT_ROOT/$(dirname "$rel")"
  cp "$PATCH_DIR/$rel" "$PROJECT_ROOT/$rel"
  echo "updated $rel"
}

copy_file "tools/maya/run_create_gaze_targets.py"
copy_file "tools/maya/run_apply_gaze_events.py"

python3 -m py_compile src/expregaze_jali/maya_apply_gaze.py
python3 - <<'PY'
from pathlib import Path
text = Path("src/expregaze_jali/maya_apply_gaze.py").read_text(encoding="utf-8")
needles = [
    "def ensure_dynamic_gaze_target_locators_from_config",
    "def build_dynamic_gaze_target_map",
    "def apply_gaze_events_from_config",
]
missing = [needle for needle in needles if needle not in text]
if missing:
    raise SystemExit("maya_apply_gaze.py missing required functions: " + ", ".join(missing))
print("maya_apply_gaze.py dynamic functions present")
PY

echo
echo "Done. Maya tools now reload expregaze_jali.maya_apply_gaze before running."
